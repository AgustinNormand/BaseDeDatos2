#define IPServidorSwitch "192.168.0.80"
#define PuertoServidorSwitch 6666

#define IPPostgresql "192.168.0.212"
#define PuertoPostgresql "5432"
#define UsernamePostgresql "SYSDBA"
#define PasswordPostgresql "masterkey"

#define IPMySql "192.168.0.211"
#define PuertoMySql "3306"
#define UsernameMysql "SYSDBA"
#define PasswordMysql "masterkey"

#define IPFirebird "127.0.0.1"
#define PuertoFirebird "3050"
#define UsernameFirebird "SYSDBA"
#define PasswordFirebird "masterkey"
#define RoleFirebird "sysdb"
#define DbPathFirebird "/var/lib/firebird/2.5/data/"
