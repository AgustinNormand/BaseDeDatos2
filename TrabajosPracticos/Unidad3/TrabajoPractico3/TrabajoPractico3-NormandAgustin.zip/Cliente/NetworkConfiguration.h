#define IPServidorSwitch "192.168.0.80"
#define PuertoServidorSwitch 6666
