import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main (String[] args) {
		VistaConsola console = new VistaConsola();
		console.Iniciar();
	}
}
