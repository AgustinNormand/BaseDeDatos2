

import vista.VistaConsola;

public class Main {
	
	public static void main(String[] args) {
		VistaConsola vc = new VistaConsola();
		vc.iniciar();
	}

}
