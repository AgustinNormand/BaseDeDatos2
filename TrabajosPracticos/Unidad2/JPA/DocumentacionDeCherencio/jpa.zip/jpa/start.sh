#/bin/bash
java -cp ../libs/jaybird/jaybird-full-2.1.6.jar:.:\
../libs/jpa/eclipselink/eclipselink/jlib/eclipselink.jar:\
../libs/jpa/glassfish-persistence/toplink-essentials.jar:\
../libs/jpa/glassfish-persistence/toplink-essentials-agent.jar Main

