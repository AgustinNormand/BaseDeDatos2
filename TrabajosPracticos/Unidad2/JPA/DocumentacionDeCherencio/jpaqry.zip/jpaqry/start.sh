#/bin/bash
java -cp ../libs/jaybird/3.0/jaybird-full-3.0.3.jar:.:\
../libs/jaybird/3.0/lib/jna-4.4.0.jar:\
../libs/jpa/eclipselink/eclipselink/jlib/eclipselink.jar:\
../libs/jpa/glassfish-persistence/toplink-essentials.jar:\
../libs/jpa/glassfish-persistence/toplink-essentials-agent.jar Main

